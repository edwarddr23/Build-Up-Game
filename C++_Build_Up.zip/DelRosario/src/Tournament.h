#pragma once
#include <iostream>
#include <fstream>
#include <vector>
#include <chrono>
#include "Round.h"

using namespace std;

class Tournament {
private:
	int humanWins = 0;
	int cpuWins = 0;
	Round round;

public:
	// Default constructor for the Tournament class.
	Tournament();

	/* *********************************************************************
	Function Name: GetRound
	Purpose: Accessor for calling Tournament object's member, round.
	Parameters: None.
	Return Value: Returns the calling Tournament object's member, round.
	Algorithm: N/A
	Assistance Received: None.
	********************************************************************* */
	Round GetRound() { return round; };

	/* *********************************************************************
	Function Name: SetHumanWins
	Purpose: Mutator for Tournament object's member, humanWins, that sets it to parameter m_humanWins.
	Parameters: (value) m_humanWins, an int passed through that the Tournament member humanWins is set to.
	Return Value: None.
	Algorithm: N/A
	Assistance Received: None.
	********************************************************************* */
	void SetHumanWins(int m_humanWins) { humanWins = m_humanWins; };

	/* *********************************************************************
	Function Name: SetCPUWins
	Purpose: Mutator for Tournament object's member, cpuWins, that sets it to parameter m_cpuWins.
	Parameters: (value) m_cpuWins, an int passed through that the Tournament member cpuWins is set to.
	Return Value: None.
	Algorithm: N/A
	Assistance Received: None.
	********************************************************************* */
	void SetCPUWins(int m_cpuWins) { humanWins = m_cpuWins; };

	/* *********************************************************************
	Function Name: SetRoundNumber
	Purpose: Mutator for Tournament object's member, round, and sets its roundNum member.
	Parameters: (value) m_roundNumber, an int passed through that the Tournament member round's roundNum member is set to.
	Return Value: None.
	Algorithm: N/A
	Assistance Received: None.
	********************************************************************* */
	void SetRoundNumber(int m_roundNumber) { round.SetRoundNum(m_roundNumber); };

	/* *********************************************************************
	Function Name: StartCurrentRound
	Purpose: Starts the Tournament's member, round, for the Tournament.
	Parameters: None.
	Return Value: None.
	Algorithm: N/A
	Assistance Received: None.
	********************************************************************* */
	void StartCurrentRound() { round.StartRound(); };

	/* *********************************************************************
	Function Name: RestoreInquiry
	Purpose: Asks the user if they want to restore a previous game if one exists. (y = Human wishes to restore previous game, n = Human wishes to start a new game).
	Parameters: None.
	Return Value: Returns true if the Human wants to restore a game, and false if the Human does not want to restore a game.
	Algorithm: 1) Ask Human if they want to restore a previous game or start a new game.
					a) If the input is "y", then the Human wants to restore a previous game. Return true.
					b) If the input is "n", then the Human does not want to restore a previous game, return false.
					c) If the input is neither, then repeat step 1).
	Assistance Received: None.
	********************************************************************* */
	bool RestoreInquiry();

	/* *********************************************************************
	Function Name: RestoreTournamnentData
	Purpose: Restore round from file parameter and assign the data taken to a restoredRound variable. Set the calling Tournament's member round to this restoredRound variable.
			 Then assign the cpuScore and humanScore members based on the information read from the save file. Returns true if there is a save file to restore from and reading is successful
			 and returns false if there isn't. Takes tournament-specific information and then calls another function to take round-specific information.
	Parameters: None.
	Return Value: Returns true if restoring the data from the save file is suceesful and false if otherwise.
	Algorithm: 1) Open save file. If opening 
	fails (meaning it doesn't exist), then print that no save file exists and return false.
			   2) Read from the save file string by string using stringstream.
			   3) If the current string read in is "Rounds", then check if the next string is "Won:". If not, then return false.
			   4) Take in another string and save it to calling Tournament object's cpuWins member.
			   5) Repeat steps 2)-4), but save to calling Tournament object's humanWins member instead.
			   6) Restore the Round data from the save file using Round::RestoreRoundData, which will modify the Tournament object's round member. If it fails somehow (returns false) return false.
			   7) Set the round member's round number to the cpuWins + humanWins Tournament members.
			   8) Display all loaded data and return true.
	Assistance Received: None.
	********************************************************************* */
	bool RestoreTournamnentData();

	/* *********************************************************************
	Function Name: SerializeRound
	Purpose: Called in main program to store the Tournament's data into a save file. Creates a new save file if one doesn't exist, and truncates if a save file is found.
	Parameters: None.
	Return Value: None.
	Algorithm: 1) Check to see if the Tournament object's round member is suspended by the Human.
					a) If not, return and don't do anything.
			   2) Since the round has not been suspended, make the Tournament's round member store its data into a string, passing in the humanWins and cpuWins members since the round can't access those.
			   3) Try to open the save file that the Human specifies
					a) If it is open, then the file does exist. Overwrite the file by truncating the round member's roundData member which has all of the round's data.
					b) If it is not open, then that means the file does not exist. Create a new saveFile called whatever the Human specifies and print the round member's roundData member onto the file.
			   4) Close the save file and return.
	Assistance Received: Learned how to open and validate whether a file exists or not from https://www.tutorialspoint.com/the-best-way-to-check-if-a-file-exists-using-standard-c-cplusplus.
						 Learned how to truncate a file from https://stackoverflow.com/questions/17032970/clear-data-inside-text-file-in-c#:~:text=If%20you%20simply%20open%20the,you'll%20delete%20the%20content.
	********************************************************************* */
	void SerializeRound();

	/* *********************************************************************
	Function Name: InitializeRound
	Purpose: Used to intiialize restored and new Rounds.
	Parameters: (value) m_restoringRound, a boolean that is used to determine whether to initialize a new Round or re-initialize a restored Round.
	Return Value: None.
	Algorithm: 1) Check the parameter m_restoringRound.
					a) If the parameter is true and the Tournament member round's number is 0, then this must be a case where the Human just started teh game and wants to restore a Round from a save file.
						A) Try to restore the Tournament's data from the save file.
							a) If this works, set the round's isRestoredRound member to true and return.
							b) if this fails, then continue to step 2).
			   2) Initialize a new Round if loading from a file fails or the Human doesn't want to resume a previous game, initialize a new Round.
					a) Set the Tournament member round's starting hand number to 1, Increment the roundNumber (as it starts at 0), and set the Human's and CPU's scores to 0
					b) Initialize the Black and White Boneyards for a new Round (handled by InitialzeBoneyards)
					c) Initialize the Players' stacks using InitializePlayersStacks.
	Assistance Received: None.
	********************************************************************* */
	void InitializeRound(bool m_restoringRound);

	/* *********************************************************************
	Function Name: AddWin
	Purpose: Used to store who won in Tournament members humanWins or cpuWins to keep track of how many times each Player won.
	Parameters: None.
	Return Value: None.
	Algorithm: 1) Check whether the Tournament's round member has been suspended.
					a) If the Round has been suspended, then return and don't do anything.
			   2) Since the Round has not been suspended, compare the Human's and CPU's scores from the Round that just finished.
					a) If the Human has a higher score than the CPU, then increment Tournament's member humanWins by 1 and print that the Human won.
					b) If the CPU has a higher score than the Human, then increment Tournament's member cpuWins by 1 and print that the CPU won.
					c) If the Human's score and CPU's score are equal, then increment both Tournament members humanWIns and cpuWins by 1 and print that there is a draw.
	Assistance Received: None.
	********************************************************************* */
	void AddWin();

	/* *********************************************************************
	Function Name: PrintWins
	Purpose: Prints the Human's total wins and the CPU's total wins.
	Parameters: None.
	Return Value: None.
	Algorithm: 1) Check whether the Tournament's round member has been suspended.
					a) If the Round has been suspended, then return and don't do anything.
			   2) Since the Round has not been suspended, print the Human's total wins and CPU's total wins.
	Assistance Received: None.
	********************************************************************* */
	void PrintWins();

	/* *********************************************************************
	Function Name: RoundInquiry
	Purpose: Asks the player whether to start a new round or not. Used to determine whether to end the Tournament and show the results or not.
	Parameters: None.
	Return Value: Returns true if the Human wants to start another round. Returns false if the Human wants to end the toournament.
	Algorithm: N/A
	Assistance Received: None.
	********************************************************************* */
	bool RoundInquiry();

	/* *********************************************************************
	Function Name: DeclareWinnerOfTournament
	Purpose: Compares human's and CPU's wins and declares winner of tournament.
	Parameters: None.
	Return Value: None.
	Algorithm: 1) Check to see if the Tournament's round member is suspended.
					a) If so, then return and don't do anything.
			   2) Since the Tournament's round member is not suspended, determine who won the Tournament.
					a) If the Human has more wins than the CPU, then print that the Human won the Tournament.
					b) If the CPU has mroe wins than the Human, then print that the CPU won the Tourrnament.
					c) If the Human and CPU have an equal amount of wins, then print that there is a draw and that neither Player won the Tournament.
			   3) Print the Human's and the CPU's wins.
	Assistance Received: None.
	********************************************************************* */
	void DeclareWinnerOfTournament();
};